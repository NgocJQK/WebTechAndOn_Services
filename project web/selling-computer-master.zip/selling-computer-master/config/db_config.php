<?php

define('DB_NAME', 'selling_computer');
// <<<<<<< HEAD
define('DB_USER', 'root');
define('DB_PASSWORD', 'mysql12345');
// =======
// define('DB_USER', 'thanh5320');
// define('DB_PASSWORD', 'thanh5320');
// >>>>>>> 42b004690c805fb66acb7917df9db30f8057e223
define('DB_HOST', 'localhost');
define('DB_PORT', "3306");
