<?php

class Type {
    public const NONE = 0;
    public const MOUSE = 1;
    public const PC = 2;
    public const LAPTOP = 3;
}