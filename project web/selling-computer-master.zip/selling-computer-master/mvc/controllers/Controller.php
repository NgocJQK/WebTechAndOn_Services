<?php

interface Controller {
    /**
     * Method use render HTML code with control by controller
     */
    function __render();
}
