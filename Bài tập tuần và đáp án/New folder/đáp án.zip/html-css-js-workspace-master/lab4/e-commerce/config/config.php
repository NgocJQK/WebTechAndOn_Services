<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);


define('DB_NAME', 'framework');
define('DB_USER', 'root');
define('DB_PASSWORD', 'mysql1234');
define('DB_HOST', 'localhost');

define('BASE_PATH','http://localhost/html-css-js-workspace/lab4/e-commerce');


define('PAGINATE_LIMIT', '5');
