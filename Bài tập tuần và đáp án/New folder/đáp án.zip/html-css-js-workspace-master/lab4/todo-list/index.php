<html>
    <head> 
        <title>HTML With PHP Embedded</title> </head>
    <body> 
        <font size=5 color=”blue”>Welcome To My Page</font>
        <?php
        print ("<br> Using PHP is not hard<br>");
        ?>
        and you can learn to use it quickly!
    </body>
</html>
