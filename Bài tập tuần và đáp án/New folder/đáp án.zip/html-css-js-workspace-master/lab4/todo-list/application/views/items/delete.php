
	<a class="big" href="../../items/viewall">Todo successfully deleted. Click here to go back.</a><br/>

