<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);

define('DB_NAME', 'todo');
define('DB_USER', 'root');
define('DB_PASSWORD', 'mysql1234');
define('DB_HOST', 'localhost:3306');
