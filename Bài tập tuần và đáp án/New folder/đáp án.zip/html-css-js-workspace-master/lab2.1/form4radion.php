<?php 
	$email = $_POST["email"];
	$contact = $_POST["contact"];

	echo "your email is $email <br />";
	echo "contact preference is $contact";
 ?>