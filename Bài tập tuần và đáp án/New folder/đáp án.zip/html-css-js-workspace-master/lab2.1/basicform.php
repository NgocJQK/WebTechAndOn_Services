<!DOCTYPE html>
<html>
<head>
	<title>Basic Form</title>
</head>
<body>
	<form action="basicform-control.php" method="POST">
		Click submit to start our initial PHP program
		<input type="text" name="Name"><br />
		<input type="submit" value="Click to Submit"><br />
		<input type="reset" value="Erase and Restart">
	</form>
</body>
</html>