<!DOCTYPE html>
<html>
<head>
	<title>Expression</title>
</head>
<body>
	<?php 
		$gr1 = 50;
		$gr2 = 100;
		$gr3 = 75;
		$avg = ($gr1 + $gr2 + $gr3) / 3;

		print "The average is $avg";	
	 ?>
</body>
</html>