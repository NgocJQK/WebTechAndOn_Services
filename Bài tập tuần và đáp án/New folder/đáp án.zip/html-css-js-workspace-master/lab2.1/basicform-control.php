<?php 
	$name = $_POST["Name"];
	print "your name is $name";
 ?>