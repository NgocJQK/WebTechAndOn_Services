# Với các project : 
- Các bạn phải import database vào mysql sau đó thay đổi file cấu hình trong thư mục config phù hợp với cấu hình trên máy bạn. 


Xem video demo ở dưới đây : <br />
[![Watch the video](https://i.pinimg.com/236x/95/d9/29/95d929405ccaa2721d32ef12b3c4f195.jpg)](https://youtu.be/vN7ubWGOi6c)
